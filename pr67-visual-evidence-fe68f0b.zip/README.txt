PR 67 visual evidence for local candidate fe68f0b05916070ada0f375313885205b67fb27e.
Wizard images are the local Distribution Central page. Booking.com responses are simulated.
Capture-method images are the deployed preview signed-out shell, not Settings content.
CSS viewport and bitmap sizes match. Device pixel ratio 1. Not stitched.
The account email was covered in two superseded Settings files and is not in this archive.
